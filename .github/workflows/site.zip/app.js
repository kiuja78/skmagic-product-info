
const ARCHIVE=window.SK_MONTH_ARCHIVE||{};
const DEFAULT_MONTH=window.SK_DEFAULT_MONTH||Object.keys(ARCHIVE).sort().reverse()[0];
let products=[];
let promos=[];
let priceDB={};

const $=s=>document.querySelector(s);
const fmt=n=>Number(n||0).toLocaleString('ko-KR')+'원';

const state={
  month:localStorage.getItem('sk_selected_month')||DEFAULT_MONTH,
  category:'전체',sub:'전체',search:'',product:null,
  sel:{}, customerType:null, promoId:null,
  cart:JSON.parse(localStorage.getItem('sk_v61_cart')||'[]')
};
const cats=['전체','프로모션','정수기','공기청정기','비데','매트리스'];

function monthText(){
  const [y,m]=(state.month||'').split('-');
  return y&&m?`${y}.${m}`:state.month;
}
function promoMonthText(){
  const m=Number((state.month||'').split('-')[1]||0);
  return m?`${m}월`:''; 
}
function loadMonth(month){
  const snap=ARCHIVE[month]||ARCHIVE[DEFAULT_MONTH];
  if(!snap)return;
  state.month=month in ARCHIVE?month:DEFAULT_MONTH;
  products=snap.products||[];
  promos=(snap.promotions||{}).entries||[];
  priceDB=(snap.contractPrices||{}).products||{};
  localStorage.setItem('sk_selected_month',state.month);
}

function subtype(p){
  const t=`${p.title||''} ${p.spec||''} ${p.features||''}`;
  if(p.category==='정수기'){if(t.includes('얼음물'))return'얼음물';if(t.includes('얼음정수기')||p.model==='WPU-IC110F')return'얼음';if(t.includes('초소형'))return'초소형';if(t.includes('직수'))return'직수형';if(t.includes('스탠드')||t.includes('그랜드'))return'스탠드형';return'일반형'}
  if(p.category==='공기청정기'){if(t.includes('올클린 디 아트'))return'올클린 디 아트';if(t.includes('올클린'))return'올클린';if(t.includes('코어'))return'코어';if(t.includes('슈퍼'))return'슈퍼';return'기타'}
  if(p.category==='비데'){if(t.includes('올클린'))return'올클린 케어';if(t.includes('풀스텐 케어'))return'풀스텐 케어';if(t.includes('스파'))return'스파';if(t.includes('파워업'))return'파워업';return'기타'}
  if(p.category==='매트리스')return p.title.includes('매트리스')?'매트리스':'프레임';
  return'';
}
function quickFeatures(p){
  if(p.model==='WPU-IAC606')return['냉수','온수','정수','얼음','미네랄'];
  const s=`${p.spec||''} ${p.features||''}`;const out=[];
  ['냉수','온수','정수','얼음','미네랄','직수','UV','살균','AI','저소음'].forEach(k=>{if(s.includes(k)&&!out.includes(k))out.push(k)});
  return out.slice(0,5);
}
function productPromos(p){return promos.filter(x=>(x.apiIds||[]).includes(p.apiId))}
function promoDisplayLabel(pr){
  if(pr.group==='반값' && pr.discountMonths) return `${pr.discountMonths}개월 반값`;
  if(pr.customerType==='크로스/재구독') return '크로스/재구독';
  if(pr.customerType==='타사보상') return '타사보상';
  return pr.group||'프로모션';
}
function renderBidetPromoSummary(p){
  if(p.category!=='비데') return '';
  const ps=productPromos(p);
  if(!ps.length) return `<span class="promo-none">${promoMonthText()} 프로모션 없음</span>`;
  const seen=new Set();
  const rows=ps.filter(pr=>{
    const key=`${promoDisplayLabel(pr)}|${pr.promoPrice}`;
    if(seen.has(key)) return false;
    seen.add(key); return true;
  });
  return `<div class="promo-mini-list">${rows.map(pr=>`
    <div class="promo-mini">
      <span>${promoDisplayLabel(pr)}</span>
      <strong>${fmt(pr.promoPrice)}</strong>
    </div>`).join('')}</div>`;
}
function entry(p){return priceDB[String(p.apiId)]||{rows:[]}}
function unique(arr){return [...new Set(arr.filter(v=>v!==undefined&&v!==null&&v!==''))]}
function availableYears(p){return unique(entry(p).rows.map(r=>r.contractYears)).sort((a,b)=>a-b)}
function priceRange(p){const a=entry(p).rows.map(r=>r.price).filter(Boolean);if(!a.length)return'';return Math.min(...a)===Math.max(...a)?fmt(a[0]):`${fmt(Math.min(...a))} ~ ${fmt(Math.max(...a))}`}
function subFilters(c){
  if(c==='프로모션')return['전체','정수기','공기청정기','비데','매트리스'];
  if(c==='정수기')return['전체','직수형','초소형','얼음','얼음물','스탠드형','일반형'];
  if(c==='공기청정기')return['전체','올클린 디 아트','올클린','코어','슈퍼','기타'];
  if(c==='비데')return['전체','올클린 케어','풀스텐 케어','스파','파워업','기타'];
  if(c==='매트리스')return['전체','SS','Q','K'];return[];
}
function mattressSizes(p){return unique(entry(p).rows.map(r=>r.size))}
function sizeLabel(s){return s==='SS'?'슈퍼싱글(SS)':s==='Q'?'퀸(Q)':s==='K'?'킹(K)':s}

function renderCats(){
  $('#categoryChips').innerHTML=cats.map(c=>{
    const label=c==='프로모션'?`🔥 ${promoMonthText()} 프로모션`:c;
    return `<button class="chip ${c==='프로모션'?'promo':''} ${state.category===c?'active':''}" data-cat="${c}">${label}</button>`;
  }).join('');
  document.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>{
    state.category=b.dataset.cat;
    state.sub='전체';
    $('#listTitle').textContent=state.category==='전체'?'전체 제품':state.category==='프로모션'?`${promoMonthText()} 프로모션`:state.category;
    renderCats();renderSub();renderProducts();
  })
}
function renderSub(){
  const a=subFilters(state.category),w=$('#subFilter');if(!a.length){w.classList.add('hidden');return}w.classList.remove('hidden');
  $('#subTitle').textContent=state.category==='프로모션'?'프로모션 제품군':state.category==='매트리스'?'사이즈':'세부구분';
  $('#subHelp').textContent=state.category==='프로모션'?'제품군별로 보기':'';
  $('#subChips').innerHTML=a.map(x=>`<button class="sub-chip ${state.sub===x?'active':''}" data-sub="${x}">${state.category==='매트리스'&&x!=='전체'?sizeLabel(x):x}</button>`).join('');
  document.querySelectorAll('[data-sub]').forEach(b=>b.onclick=()=>{state.sub=b.dataset.sub;renderSub();renderProducts()})
}
function filtered(){
  const q=state.search.trim().toLowerCase();
  return products.filter(p=>{
    if(state.category==='프로모션'){if(!productPromos(p).length)return false;if(state.sub!=='전체'&&p.category!==state.sub)return false}
    else{if(state.category!=='전체'&&p.category!==state.category)return false;if(state.sub!=='전체'){if(state.category==='매트리스'){if(!mattressSizes(p).includes(state.sub))return false}else if(subtype(p)!==state.sub)return false}}
    return !q||`${p.title} ${p.model} ${p.spec||''} ${p.features||''}`.toLowerCase().includes(q)
  })
}
function renderProducts(){
  const list=filtered();$('#count').textContent=`${list.length}개`;
  $('#productGrid').innerHTML=list.length?list.map(p=>{
    const years=availableYears(p);
    const prom=productPromos(p).length;
    const special=entry(p).rows.some(r=>r.pricingType==='사용연차');
    return `<article class="card">
      <div class="card-main">
        <button class="photo" data-official="${p.apiId}">
          <img src="${p.cover||''}" alt="" referrerpolicy="no-referrer" onerror="this.style.display='none'">
          <em>SK매직 공식 상세 ↗</em>
        </button>
        <div>
          <div class="badges"><i>${p.category}</i><i>${subtype(p)}</i>${prom?`<i class="hot">🔥 ${promoMonthText()} 혜택</i>`:''}</div>
          <h3>${p.title}</h3><div class="model">${p.model}</div>
          <div class="feature-row">${quickFeatures(p).map(x=>`<span class="feature">${x}</span>`).join('')}</div>
          <div class="contract-summary">
            <b>${special?'사용연차별 가격':years.length?`의무사용 ${years.join('·')}년`:'계약가격'}</b>
            <p>${special?'기간에 따라 월요금이 달라집니다.':`계약조건별 ${priceRange(p)} · 정확한 금액은 조건 선택 후 표시`}</p>
          </div>
          ${renderBidetPromoSummary(p)}
        </div>
      </div>
      <div class="card-actions"><button data-official="${p.apiId}">공식 상세</button><button class="calc" data-calc="${p.apiId}">가격 · 수수료</button></div>
    </article>`
  }).join(''):'<div class="cart-empty" style="grid-column:1/-1">조건에 맞는 제품이 없습니다.</div>';
  document.querySelectorAll('[data-official]').forEach(b=>b.onclick=()=>openOfficial(Number(b.dataset.official)));
  document.querySelectorAll('[data-calc]').forEach(b=>b.onclick=()=>openSheet(Number(b.dataset.calc)));
}
function openOfficial(id){const p=products.find(x=>x.apiId===id);if(p?.officialDetailUrl)window.open(p.officialDetailUrl,'_blank','noopener,noreferrer')}
function closeSheet(){$('#sheet').classList.add('hidden');$('#backdrop').classList.add('hidden');document.body.style.overflow=''}
$('#closeSheet').onclick=closeSheet;$('#backdrop').onclick=closeSheet;$('#officialBtn').onclick=()=>openOfficial(state.product.apiId);$('#officialImageBtn').onclick=()=>openOfficial(state.product.apiId);

const dimensions=[
  ['variant','제품/필터'],
  ['size','사이즈'],
  ['management','관리방식'],
  ['plan','케어/요금제'],
  ['visitCycleMonths','관리주기'],
  ['contractYears','의무사용기간']
];
function labelVal(k,v){
  if(k==='size')return sizeLabel(v);
  if(k==='visitCycleMonths')return `${v}개월`;
  if(k==='contractYears')return `${v}년`;
  if(k==='plan')return String(v).toUpperCase();
  return v;
}
function standardRows(){return entry(state.product).rows.filter(r=>!r.pricingType)}
function filteredBySelections(rows,ignoreKey=null){
  return rows.filter(r=>Object.entries(state.sel).every(([k,v])=>k===ignoreKey||v===undefined||r[k]===v))
}
function normalizeSelections(){
  const rows=standardRows();let prior={};
  dimensions.forEach(([key])=>{
    const possible=unique(rows.filter(r=>Object.entries(prior).every(([k,v])=>r[k]===v)).map(r=>r[key]));
    if(!possible.length){delete state.sel[key];return}
    if(!possible.some(v=>v===state.sel[key]))state.sel[key]=possible[0];
    prior[key]=state.sel[key];
  })
}
function renderSelectors(){
  const rows=standardRows(),box=$('#selectors'),special=$('#specialPricing');
  const ent=entry(state.product);
  const warn=$('#dataWarning');
  if(ent.dataCompleteness==='summary-only'){
    warn.textContent=ent.note||'이 제품은 상세 계약기간별 가격표가 아직 수집되지 않아 e-book 요약 가격을 표시합니다.';
    warn.classList.remove('hidden');
  }else if(ent.dataCompleteness==='partial-official'){
    warn.textContent=ent.note||'현재 확보된 공식 상세가격 범위만 표시합니다.';
    warn.classList.remove('hidden');
  }else{
    warn.classList.add('hidden');
  }
  if(!rows.length){box.innerHTML='';special.classList.remove('hidden');special.innerHTML=entry(state.product).rows.map(r=>`<div class="special-row"><span>${r.serviceYearFrom}~${r.serviceYearTo}년차</span><strong>${fmt(r.price)}</strong></div>`).join('');return}
  special.classList.add('hidden');normalizeSelections();
  let prior={};let html='';
  dimensions.forEach(([key,title])=>{
    const vals=unique(rows.filter(r=>Object.entries(prior).every(([k,v])=>r[k]===v)).map(r=>r[key]));
    if(vals.length){
      html+=`<div class="selector-group"><label>${title}</label><div class="seg">${vals.map(v=>`<button data-dim="${key}" data-val="${encodeURIComponent(String(v))}" class="${state.sel[key]===v?'active':''}">${labelVal(key,v)}</button>`).join('')}</div></div>`;
      prior[key]=state.sel[key];
    }
  });
  box.innerHTML=html;
  document.querySelectorAll('[data-dim]').forEach(b=>b.onclick=()=>{
    const key=b.dataset.dim;const raw=decodeURIComponent(b.dataset.val);
    const sample=rows.find(r=>String(r[key])===raw)?.[key];
    state.sel[key]=sample;
    const idx=dimensions.findIndex(x=>x[0]===key);dimensions.slice(idx+1).forEach(([k])=>delete state.sel[k]);
    state.promoId=null;renderCalc();
  })
}
function selectedRow(){
  const rows=standardRows();if(!rows.length)return null;
  return rows.find(r=>Object.entries(state.sel).every(([k,v])=>v===undefined||r[k]===v))||rows[0]
}
function rowSummary(r){
  if(!r)return'';
  const a=[];if(r.variant)a.push(r.variant);if(r.size)a.push(sizeLabel(r.size));if(r.management)a.push(r.management);if(r.plan)a.push(String(r.plan).toUpperCase());if(r.visitCycleMonths)a.push(`${r.visitCycleMonths}개월 주기`);if(r.contractYears)a.push(`의무 ${r.contractYears}년`);if(r.ownershipYears)a.push(`소유 ${r.ownershipYears}년`);return a.join(' · ')
}
function renderMembership(){
  const m=entry(state.product).memberships||[],w=$('#membershipBlock');
  if(!m.length){w.classList.add('hidden');return}w.classList.remove('hidden');
  $('#membershipList').innerHTML=m.map(x=>`<div class="membership-item"><span>${[x.management,x.visitCycleMonths?x.visitCycleMonths+'개월':''].filter(Boolean).join(' · ')}</span><strong>${fmt(x.price)}</strong></div>`).join('')
}
function promoMatchesRow(p,row){
  if(!row)return true;
  if(p.contractYears&&row.contractYears&&Number(p.contractYears)!==Number(row.contractYears))return false;
  const m=p.managementType||'';
  if(m.includes('방문')&&row.management&&row.management!=='방문형')return false;
  if(m.includes('셀프')&&row.management&&row.management!=='셀프형')return false;
  const mm=m.match(/(\d+)개월/);
  if(mm&&row.visitCycleMonths&&Number(mm[1])!==Number(row.visitCycleMonths))return false;
  return true;
}
function renderPromos(row){
  const all=productPromos(state.product),block=$('#promoBlock');
  $('#promoBlockTitle').textContent=`🔥 ${promoMonthText()} 프로모션`;
  if(!all.length){block.classList.add('hidden');state.promoId=null;return}
  block.classList.remove('hidden');
  const types=unique(all.map(x=>x.customerType));
  if(!types.includes(state.customerType))state.customerType=types[0]||null;
  $('#customerTypes').innerHTML=types.map(t=>`<button class="${state.customerType===t?'active':''}" data-customer="${t}">${t}</button>`).join('');
  document.querySelectorAll('[data-customer]').forEach(b=>b.onclick=()=>{state.customerType=b.dataset.customer;state.promoId=null;renderPromos(selectedRow());updatePrice()});
  const matched=all.filter(p=>(!state.customerType||p.customerType===state.customerType)&&promoMatchesRow(p,row));
  if(state.promoId&&!matched.some(x=>promoKey(x)===state.promoId))state.promoId=null;
  $('#promoList').innerHTML=matched.length?matched.map(p=>{
    const key=promoKey(p),active=state.promoId===key;
    return `<button class="promo-card ${active?'active':''}" data-promo="${encodeURIComponent(key)}">
      <h4>${p.promoName}</h4>
      <div class="condition">${p.customerType} · ${p.managementType||''} · ${p.contractYears?`의무 ${p.contractYears}년`:''}</div>
      <div class="promo-flow">${p.basePriceInPromo?`<del>${fmt(p.basePriceInPromo)}</del>`:''}<strong>${fmt(p.promoPrice)}</strong>${p.discountMonths?`<i>${p.discountMonths}개월 적용</i>`:''}</div>
      <p>${p.discountMonths&&p.priceAfterDiscount?`${p.discountMonths}개월 이후 ${fmt(p.priceAfterDiscount)}`:''}${p.note?` · ${p.note}`:''}</p>
    </button>`
  }).join(''):`<div class="no-promo">현재 선택한 계약조건에 해당하는 ${promoMonthText()} 프로모션이 없습니다.</div>`;
  document.querySelectorAll('[data-promo]').forEach(b=>b.onclick=()=>{const k=decodeURIComponent(b.dataset.promo);state.promoId=state.promoId===k?null:k;renderPromos(selectedRow());updatePrice()})
}
function promoKey(p){return [p.page,p.sourceModel,p.customerType,p.managementType,p.contractYears,p.discountMonths,p.promoPrice].join('|')}
function selectedPromo(){return productPromos(state.product).find(p=>promoKey(p)===state.promoId)||null}

function renderCalc(){
  const p=state.product;
  $('#selCategory').textContent=p.category;$('#selSubtype').textContent=subtype(p);$('#selTitle').textContent=p.title;$('#selModel').textContent=p.model;$('#selImage').src=p.cover||'';
  $('#quickFeatures').innerHTML=quickFeatures(p).map(x=>`<span class="feature">${x}</span>`).join('');
  renderSelectors();const r=selectedRow();renderMembership();renderPromos(r);updatePrice()
}
function updatePrice(){
  const r=selectedRow(),special=entry(state.product).rows.filter(x=>x.pricingType);
  if(r){$('#officialPrice').textContent=fmt(r.price);$('#officialSummary').textContent=rowSummary(r)}
  else if(special.length){$('#officialPrice').textContent='사용연차 선택형';$('#officialSummary').textContent='상단 사용연차별 가격표를 확인하세요.'}
  else{$('#officialPrice').textContent='-';$('#officialSummary').textContent=''}
  const p=selectedPromo();
  const apply=p?p.promoPrice:(r?r.price:0);
  $('#applyPrice').textContent=apply?fmt(apply):'-';
  if(p){
    const parts=[p.promoName];
    if(p.discountMonths){
      if(p.basePriceInPromo) parts.push(`할인 전 ${fmt(p.basePriceInPromo)}`);
      parts.push(`${p.discountMonths}개월 적용`);
      if(p.priceAfterDiscount) parts.push(`이후 ${fmt(p.priceAfterDiscount)}`);
    }else{
      parts.push(`프로모션가 ${fmt(p.promoPrice)}`);
      if(p.managementType) parts.push(p.managementType);
      if(p.contractYears) parts.push(`의무 ${p.contractYears}년`);
    }
    $('#applyMeta').textContent=parts.join(' · ');
  }else{
    $('#applyMeta').textContent='공식 계약가 기준';
  }
  updateCommission()
}
function updateCommission(){
  const amount=Number($('#applyPrice').textContent.replace(/[^\d]/g,''))||0;
  const c=Number($('#contractMultiplier').value),pm=Number($('#profitMultiplier').value),rr=$('#payoutRate').value,rate=rr===''?NaN:Number(rr)/100,extra=Number($('#extraCommission').value||0);
  if(amount&&c>0&&pm>0&&Number.isFinite(rate)){const v=Math.round(amount*c*pm*rate+extra);$('#commissionResult').textContent=fmt(v);$('#commissionResult').dataset.value=v}
  else{$('#commissionResult').textContent='정책값 입력 필요';$('#commissionResult').dataset.value=''}
}
['contractMultiplier','profitMultiplier','payoutRate','extraCommission'].forEach(id=>$('#'+id).addEventListener('input',updateCommission));

function openSheet(id){
  state.product=products.find(p=>p.apiId===id);state.sel={};state.customerType=null;state.promoId=null;
  renderCalc();$('#sheet').classList.remove('hidden');$('#backdrop').classList.remove('hidden');document.body.style.overflow='hidden'
}
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toast.tm);toast.tm=setTimeout(()=>t.classList.remove('show'),1300)}
$('#addBtn').onclick=()=>{
  const r=selectedRow(),p=selectedPromo();const apply=Number($('#applyPrice').textContent.replace(/[^\d]/g,''))||0;
  const commission=Number($('#commissionResult').dataset.value||0);
  state.cart.unshift({id:Date.now(),title:state.product.title,model:state.product.model,condition:r?rowSummary(r):'사용연차별',promo:p?p.promoName:'',monthly:apply,commission});
  localStorage.setItem('sk_v61_cart',JSON.stringify(state.cart));renderCart();toast('계산내역에 추가했습니다');closeSheet()
}
function renderCart(){
  $('#cartList').innerHTML=state.cart.length?state.cart.map(x=>`<div class="cart-item"><div><b>${x.title}</b><small>${x.model} · ${x.condition}${x.promo?' · '+x.promo:''} · 월 ${fmt(x.monthly)}</small></div><div><strong>${x.commission?fmt(x.commission):'정책값 미입력'}</strong><button data-remove="${x.id}">삭제</button></div></div>`).join(''):'<div class="cart-empty">아직 계산한 제품이 없습니다.</div>';
  document.querySelectorAll('[data-remove]').forEach(b=>b.onclick=()=>{state.cart=state.cart.filter(x=>String(x.id)!==b.dataset.remove);localStorage.setItem('sk_v61_cart',JSON.stringify(state.cart));renderCart()});
  $('#totalCommission').textContent=fmt(state.cart.reduce((s,x)=>s+Number(x.commission||0),0))
}
$('#clearCart').onclick=()=>{if(state.cart.length&&confirm('계산내역을 모두 삭제할까요?')){state.cart=[];localStorage.setItem('sk_v61_cart','[]');renderCart()}};
$('#searchInput').addEventListener('input',e=>{state.search=e.target.value;renderProducts()});$('#clearSearch').onclick=()=>{$('#searchInput').value='';state.search='';renderProducts()};

function renderMonthSelect(){
  const months=Object.keys(ARCHIVE).sort().reverse();
  $('#monthSelect').innerHTML=months.map(m=>`<option value="${m}" ${m===state.month?'selected':''}>${ARCHIVE[m]?.label||m.replace('-','.')}</option>`).join('');
  $('#monthCurrent').textContent=monthText();
  $('#monthSelect').onchange=e=>{
    closeSheet();
    loadMonth(e.target.value);
    $('#monthCurrent').textContent=monthText();
    state.category='전체';
    state.sub='전체';
    state.search='';
    $('#searchInput').value='';
    $('#listTitle').textContent='전체 제품';
    renderCats();renderSub();renderProducts();
    toast(`${monthText()} 기준 가격으로 변경했습니다`);
  };
}

loadMonth(state.month);
renderMonthSelect();
renderCats();renderSub();renderProducts();renderCart();
